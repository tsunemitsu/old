print("こんにちは")
print("Hello world" , "Hello world02")
