

def mul(a , b):
    return a * b

print(mul(2 , 3))
print(mul(5 , 9))
