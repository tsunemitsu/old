
# BMI

toll=input("身長(m)を入力してください。")
weight=input("体重(kg)を入力してください。")

bmi=float(weight) / (float(toll) * float(toll))

# print("BMI = " + bmi)

print("BMI = {bmi}".format(bmi = bmi))

if bmi < 18.5:
    result = "低体重"
elif bmi < 25:
    result = "標準"
elif bmi < 30:
    result = "肥満(1度)"
elif bmi < 35:
    result = "肥満(2度)"
elif bmi < 40:
    result = "肥満(3度)"
else:
    result = "肥満(4度)"

print("結果 = " + result)
