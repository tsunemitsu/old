

print(type(30))
print(type(3.14))
print(type("Python"))

value=123
print(type(value))
