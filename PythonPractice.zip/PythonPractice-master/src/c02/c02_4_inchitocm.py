
perInch=2.54
inch=input("インチを入力してください")

# inchf=inch
inchf=float(inch)

# cm= inch * perInch
cm= inchf * perInch
des="{inch}は{cm}センチです".format(inch=inchf , cm=cm)
print(des)
