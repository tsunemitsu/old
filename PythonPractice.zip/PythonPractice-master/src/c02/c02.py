

print("-----改行-----")
print("我輩は猫である。" , end="")
print("名前と改行はまだない。")

# 三重引用符で複数行にワラル文字列を入力
print()
print("-----三重引用符-----")
str="""\
今日は良い天気です。
明日も良い天気です。
でも明後日は雨です。\
"""
print(str)

# format
print()
print("-----format-----")
print("私は{name}です。".format(name="カリギュラ"))
fmt="年齢は{age}で、{job}をやっています。"
jobname="カリギュラ"
s=fmt.format(age=29 , job=jobname)
print(s)

# input
print()
print("-----input-----")
name=input("お名前は?")
print("こんにちは" + name + "さん。")
