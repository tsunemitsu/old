#!/usr/bin/env python
# -*- coding: utf-8 -*-

import random

# ヘッダ情報を出力
print('Content-type: text/html; charset=UTF-8')

# ヘッダと本体データを区切る空行
print('')

# ランダムな数値を取得
no = random.randint(1,6)

# 本体のデータを出力
print('''
<html>
<head><meta charset="UTF-8"><title>Dice</title></head>
<body>
    <h1>{num}</h1>
</body>
</html>
'''.format(num=no))
