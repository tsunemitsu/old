#!/usr/bin/env python
# -*- coding: utf-8 -*-

# ヘッダ情報を出力
print('Content-type: text/html; charset=UTF-8')

# ヘッダと本体データを区切る空行
print('')

# 本体のデータを出力
print('<html><head><meta charset="UTF-8"></head><body>')
print('聞くことに早く語ることに遅くあるべき')
print('</body></html>')
