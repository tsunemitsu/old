function triangle(base, height) {
	return base * height / 2;
}
