// document.writelnは表示された文字列を表示するための命令
document.writeln('Hello World');
