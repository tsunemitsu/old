#!/usr/bin/env perl
use strict;   #厳密な書式を定めたり, 未定義の変数を警告するといった効果があります
use warnings; #望ましくない記述を警告してくれる効果があります

use Data::Dumper;

my %my_profile = (
    name => 'wada',
    age  => '42',
    # Perlは最後の項目に,が存在することを許す言語
    food => 'Sushi',
    book => 3,
    twitter => 'sironekotoro'
);

# ハッシュのkeyを配列で返す関数
my @keys = keys %my_profile;
print "@keys", "\n";

print "keyのageを削除する", "\n";
delete $my_profile{age};

# ハッシュのkeyを配列で返す関数
# age削除後
my @keys2 = keys %my_profile;
print "@keys2", "\n";

# keyの存在を確認する関数
if (exists $my_profile{age}) {
    print "Age is exist.\n"  # => 'exists'
}else {
    print "Age isn't exist.\n"  # => 'exists'
}

__END__

print $my_profile{name},  "\n";
print $my_profile{age},   "\n";
print $my_profile{food},  "\n";

# ハッシュのkeyを配列で返す関数
my @keys = keys %my_profile;
print "@keys", "\n";

# ハッシュのvalueを配列で返す関数
my @values = values %my_profile;
print "@values", "\n";

# keyの存在を確認する関数
if (exists $my_profile{food})  { print "exists\n" } #=> 'exists'
if (exists $my_profile{job})   { print "exists\n" } # 何も出てこない

my @keys = keys %my_profile;
for my $key (@keys) {
    print $key, ' ', $my_profile{$key}, "\n";
}


__END__
