#!/usr/bin/env perl
use strict;   #厳密な書式を定めたり, 未定義の変数を警告するといった効果があります
use warnings; #望ましくない記述を警告してくれる効果があります

print "Perl Entrance #1"
print "Hello, world!\n";
print "\n";

print "練習問題1\n";
print "2017/11/25 Perl Entrance DNP五反田ビルin東京#1\n";
print "DNP!, DNP!\n";
print "\n";

print "練習問題2\n";
print "2017年でPerlは".(2017 - 1987)."歳";
print "\n";
