#!/usr/bin/env perl
use strict;   #厳密な書式を定めたり, 未定義の変数を警告するといった効果があります
use warnings; #望ましくない記述を警告してくれる効果があります

print 'input>';
# 標準入力を受け付ける
my $str = <STDIN>;
# chompで末尾の開業を削除する
chomp $str;
print "$str\n";
