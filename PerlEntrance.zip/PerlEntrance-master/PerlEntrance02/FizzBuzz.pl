#!/usr/bin/env perl
use strict;   #厳密な書式を定めたり, 未定義の変数を警告するといった効果があります
use warnings; #望ましくない記述を警告してくれる効果があります

# my @array = (1..100);
# for my $temp (@array) {
for my $temp (1..100) {
    # if ($temp % 3 == 0 && $temp % 5 == 0) {
    # 3も5も素数であるため、積で割れるものはFizzBuzzとなる
    if ($temp % 15 == 0) {
        print "FizzBuzz\n";
    }elsif ($temp % 3 == 0) {
        print "Fizz\n";
    }elsif ($temp % 5 == 0) {
        print "Buzz\n";
    }else {
        print "$temp\n";
    }
}
