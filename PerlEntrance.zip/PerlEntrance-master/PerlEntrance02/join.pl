#!/usr/bin/env perl
use strict;   #厳密な書式を定めたり, 未定義の変数を警告するといった効果があります
use warnings; #望ましくない記述を警告してくれる効果があります

# my @array = ("0123", "123", "XXX");
my @array = qw("0123", "123", "XXX");
print join "-", @array;
print "\n";
