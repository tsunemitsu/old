#!/usr/bin/env perl
use strict;   #厳密な書式を定めたり, 未定義の変数を警告するといった効果があります
use warnings; #望ましくない記述を警告してくれる効果があります

my $answer = 'perl'; # 好きな文字を入れておく

print "文字列を入力してください >";
my $input = <STDIN>;
chomp $input;

if ($answer eq $input) {
    print "OK\n";
}else {
    print "NG\n";
}

#
# my $true = 1;
# for (;;) {
#     print "文字列を入力してくださいpart2 >";
#     my $input = <STDIN>;
#     if ($answer eq $input) {
#         print "OK\n";
#         last;
#     }else {
#         print "NG\n";
#     }
# }
