#!/usr/bin/env perl
use strict;   #厳密な書式を定めたり, 未定義の変数を警告するといった効果があります
use warnings; #望ましくない記述を警告してくれる効果があります

my $foo = 1;
if ( $foo == 1 ) {
    print "OK\n";
}else {
    print "NG\n";
}

# このような場合, Perlは文字列を無理やり数値として解釈して処理を継続します
# この場合, '42strings'には先頭に42という数値が含まれているので,
# Perlは==の演算子の左辺は42として処理を実行します
if('42strings' == 42) {
    print "OK\n";
}
