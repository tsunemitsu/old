#!/usr/bin/env perl
use strict;   #厳密な書式を定めたり, 未定義の変数を警告するといった効果があります
use warnings; #望ましくない記述を警告してくれる効果があります

print 'Your Name? >';
# 標準入力を受け付ける
my $str = <STDIN>;
# chompで末尾の開業を削除する
chomp $str;
# print "Hello "."$str"." !\n";
print "Hello $str !\n";

print 'Your OS? >';
my $strOS = <STDIN>;
chomp $strOS;
# print "$strOS"." is useful OS!\n"
print "$strOS is useful OS!\n";
