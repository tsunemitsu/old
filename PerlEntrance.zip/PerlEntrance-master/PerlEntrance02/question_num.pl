#!/usr/bin/env perl
use strict;   #厳密な書式を定めたり, 未定義の変数を警告するといった効果があります
use warnings; #望ましくない記述を警告してくれる効果があります

my $answer = 10; # 好きな文字を入れておく

print "数字を入力してください >";
my $input = <STDIN>;
chomp $input;

if($input eq ''){
    print "カラモジ\n";
    exit;
}

# abs = 絶対値
my $temp = abs($answer - $input);

if ($answer == $input) {
    print "OK\n";
# }elsif($answer -5 <= $input && $input <= $answer + 5) {
}elsif($temp <= 5) {
    print "near";
    print "\n";
}elsif($answer < $input) {
    print "too big";
    print "\n";
}elsif($answer > $input) {
    print "too small";
    print "\n";
}

#
# my $true = 1;
# for (;;) {
#     print "文字列を入力してくださいpart2 >";
#     my $input = <STDIN>;
#     if ($answer eq $input) {
#         print "OK\n";
#         last;
#     }else {
#         print "NG\n";
#     }
# }
