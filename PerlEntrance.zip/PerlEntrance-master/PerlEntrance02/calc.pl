#!/usr/bin/env perl
use strict;   #厳密な書式を定めたり, 未定義の変数を警告するといった効果があります
use warnings; #望ましくない記述を警告してくれる効果があります

print 'First  Num? >';
# 標準入力を受け付ける
my $num01 = <STDIN>;
# chompで末尾の開業を削除する
chomp $num01;

print 'Second Num? >';
my $num02 = <STDIN>;
chomp $num02;

# print "$num01"." + "."$num02"." = ".($num01 + $num02);
# print "\n";
# print "$num01 + $num02"." = ".($num01 + $num02);
# print "\n";
print "$num01 + $num02 = ",$num01 + $num02;
print "\n";
print "$num01 - $num02 = ".($num01 - $num02);
print "\n";
print "$num01 x $num02 = ".($num01 * $num02);
print "\n";
print "$num01 / $num02 = ".($num01 / $num02);
print "\n";
