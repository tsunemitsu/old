#!/usr/bin/env perl
use strict;   #厳密な書式を定めたり, 未定義の変数を警告するといった効果があります
use warnings; #望ましくない記述を警告してくれる効果があります

my @array = ("ぜろ",1,2,3,"よん");
for my $temp (@array) {
    print $temp;
    print "\n";
}

print "-----------------";
print "\n";
print "数字か文字列を3回入力 >";
my $input00 = <STDIN>;
chomp $input00;
my $input01 = <STDIN>;
chomp $input01;
my $input02 = <STDIN>;
chomp $input02;

my @arrayI = ($input00, $input01, $input02);

print "inputを表示 = ";
for my $temp (@arrayI) {
    print $temp, " ";
    # print "\n";
}
print "\n";
