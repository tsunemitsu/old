#!/usr/bin/env perl
use strict;   #厳密な書式を定めたり, 未定義の変数を警告するといった効果があります
use warnings; #望ましくない記述を警告してくれる効果があります

my $fuga = 100;
my $hoge = 50;

print "fuga is $fuga\n";
print "hoge is $hoge\n";

$fuga += 1;
print "fuga is $fuga\n";

# ピリオドで文字列を連結
print 111 . 22 . 33;
print "\n";
# カンマで文字列を連結
print 111 , 22 , 33;
print "\n";

# $, という特殊な変数がある
# $, = "///" などの定義する
# $, に代入された値でpinrtの引数を区切る
# だだし $,はあまり使わない

my $foo = 'hoge';
my $bar = 123;
print $foo.$bar;
print "\n";



my $now = 2017;
my $last_showa = 1988;
#  - . と - は同じ優先順位で左結合のため、左から演算されます    - 始めに、今年は平成 と 2017 を文字連結します
print "今年は平成" . $now - $last_showa . "年です\n";
# ()で演算の順序を変更することで、正しい結果になりました
print "今年は平成" . ( $now - $last_showa ) . "年です\n";
# 計算結果を別の変数に入れるのも良いでしょう
my $heisei = $now - $last_showa;
print "今年は平成$heisei年です\n";
